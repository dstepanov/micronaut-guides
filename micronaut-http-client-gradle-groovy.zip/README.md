## Micronaut 5.1.3 Documentation

- [User Guide](https://docs.micronaut.io/5.1.3/guide/index.html)
- [API Reference](https://docs.micronaut.io/5.1.3/api/index.html)
- [Configuration Reference](https://docs.micronaut.io/5.1.3/guide/configurationreference.html)
- [Micronaut Guides](https://guides.micronaut.io/index.html)
---

- [Micronaut Gradle Plugin documentation](https://micronaut-projects.github.io/micronaut-gradle-plugin/latest/)
- [Shadow Gradle Plugin](https://gradleup.com/shadow/)
## Feature micronaut-aot documentation


- [Micronaut AOT documentation](https://micronaut-projects.github.io/micronaut-aot/latest/guide/)


## Feature spotless documentation


- [https://github.com/diffplug/spotless](https://github.com/diffplug/spotless)


## Feature serialization-jackson documentation


- [Micronaut Serialization Jackson Core documentation](https://micronaut-projects.github.io/micronaut-serialization/latest/guide/)


## Feature http-client documentation


- [Micronaut HTTP Client documentation](https://docs.micronaut.io/latest/guide/index.html#nettyHttpClient)


