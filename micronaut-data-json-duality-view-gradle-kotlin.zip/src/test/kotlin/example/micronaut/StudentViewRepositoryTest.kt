/*
 * Copyright 2017-2026 original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package example.micronaut

import example.micronaut.domain.StudentScheduleClassSubView
import example.micronaut.domain.StudentScheduleSubView
import example.micronaut.domain.StudentView
import io.micronaut.test.extensions.junit5.annotation.MicronautTest
import jakarta.inject.Inject
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertTrue

@MicronautTest
class StudentViewRepositoryTest {

    @Inject
    lateinit var studentViewRepository: StudentViewRepository

    @Inject
    lateinit var classRepository: ClassRepository

    @Test
    fun testCreateStudentView() {
        val mathClass = classRepository.save(example.micronaut.domain.Class(null, "Math"))
        val studentScheduleClassSubView = StudentScheduleClassSubView(mathClass.id, mathClass.name)
        val studentScheduleSubView = StudentScheduleSubView(0L, studentScheduleClassSubView)
        val studentView = StudentView(null, "John", listOf(studentScheduleSubView), mapOf("department" to "Research", "remote" to true))
        studentViewRepository.save(studentView)
        val student = studentViewRepository.findByName(studentView.name)
        assertTrue(student.isPresent)
        val savedStudent = student.orElseThrow()
        assertEquals("Research", savedStudent.extras["department"])
        assertEquals(true, savedStudent.extras["remote"])
        assertEquals(1, savedStudent.classes.size)
        assertEquals("Math", savedStudent.classes[0].clazz.name)
    }
}
